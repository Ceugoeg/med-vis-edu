#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import math
import time


class InteractionHSM:
    def __init__(self):
        """
        边缘端启发式状态机 (Heuristic State Machine)
        严格复刻 mediapipe_hand_publisher.js 中的手势识别与防抖管线。
        其职责是将 21 个 3D 坐标坍缩为稳定的离散控制信号 (NONE, OPEN, PINCH, FIST)，供前端的三维物理引擎消费。
        """
        self.config = {
            'pinchThreshold': 0.055,
            'dynamicPinch': True,
            'pinchRatioThreshold': 0.34,
            'pinchOpenBaselineCount': 2,

            'openEnterExtensionThreshold': 0.035,
            'openExitExtensionThreshold': 0.02,
            'openEnterYGapThreshold': -0.065,
            'openExitYGapThreshold': -0.045,

            'fistEnterCurlThreshold': -0.01,
            'fistExitCurlThreshold': -0.004,
            'fistEnterYGapAbsThreshold': 0.065,
            'fistExitYGapAbsThreshold': 0.08,

            'thumbExtendedEnterThreshold': 0.05,
            'thumbExtendedExitThreshold': 0.04,
            'thumbCurledEnterThreshold': 0.065,
            'thumbCurledExitThreshold': 0.075,

            'stateVoteWindow': 5,
            'openConfirmFramesAfterAction': 2,
            'stateHoldFrames': 1,
            'forceFistAfterMs': 300
        }

        self.stable_state = 'NONE'
        self.candidate_state = 'NONE'
        self.candidate_frames = 0
        self.state_history = []
        self.open_candidate_frames = 0
        self.force_fist_start_ms = None

    def _distance3(self, a, b):
        dx = a['x'] - b['x']
        dy = a['y'] - b['y']
        dz = a['z'] - b['z']
        return math.sqrt(dx * dx + dy * dy + dz * dz)

    def update(self, smoothed_landmarks):
        """
        主处理管线：传入滤波后的坐标，输出防抖后的稳态手势
        """
        if not smoothed_landmarks or len(smoothed_landmarks) != 21:
            self.state_history.clear()
            self.open_candidate_frames = 0
            self.force_fist_start_ms = None
            fallback_state = 'FIST' if self.stable_state == 'FIST' else 'NONE'
            return self._commit_state(fallback_state)

        # Python 时间戳单位是秒，前端是毫秒，做对齐
        now_ms = time.time() * 1000.0

        # 1. 检测强制 FIST 候选状态 (降级宽容判定)
        hold_fist_candidate = self._detect_force_fist_candidate(smoothed_landmarks)
        self._update_force_fist_timer(hold_fist_candidate, now_ms)

        # 2. 原始几何判定
        raw_state = self._detect_gesture(smoothed_landmarks)

        # 3. 触发延时强制 FIST 覆盖
        if self._should_force_fist(raw_state, now_ms):
            raw_state = 'FIST'

        # 4. 应用转换约束 (防止误触 OPEN 释放操作)
        constrained_state = self._apply_transition_constraints(raw_state)

        # 5. 滑动窗口投票滤波
        voted_state = self._vote_state(constrained_state)

        # 6. 确认稳态并返回
        stable = self._commit_state(voted_state)

        return stable

    def _update_force_fist_timer(self, is_candidate, now_ms):
        if not is_candidate:
            self.force_fist_start_ms = None
            return
        if self.force_fist_start_ms is None:
            self.force_fist_start_ms = now_ms

    def _should_force_fist(self, raw_state, now_ms):
        if raw_state != 'NONE':
            return False
        if self.stable_state not in ('NONE', 'FIST'):
            return False
        if self.force_fist_start_ms is None:
            return False
        return (now_ms - self.force_fist_start_ms) >= self.config['forceFistAfterMs']

    def _detect_force_fist_candidate(self, landmarks):
        wrist = landmarks[0]
        finger_pairs = [(8, 5), (12, 9), (16, 13), (20, 17)]

        loose_curl_threshold = self.config['fistExitCurlThreshold'] + 0.02
        curled = []
        for tip_idx, mcp_idx in finger_pairs:
            tip_dist = self._distance3(landmarks[tip_idx], wrist)
            mcp_dist = self._distance3(landmarks[mcp_idx], wrist)
            delta = tip_dist - mcp_dist
            curled.append(delta < loose_curl_threshold)

        index_curled = curled[0]
        middle_curled = curled[1]
        curled_count_loose = sum(curled)

        return (index_curled or middle_curled) and curled_count_loose >= 2

    def _apply_transition_constraints(self, raw_state):
        if self.stable_state == 'FIST' and raw_state == 'NONE':
            return 'FIST'

        if raw_state == 'OPEN':
            self.open_candidate_frames += 1
        else:
            self.open_candidate_frames = 0

        from_state = self.stable_state
        leaving_critical_state = from_state in ('FIST', 'PINCH')

        if leaving_critical_state and raw_state == 'OPEN' and self.open_candidate_frames < self.config[
            'openConfirmFramesAfterAction']:
            return 'NONE'

        return raw_state

    def _vote_state(self, state):
        self.state_history.append(state)
        if len(self.state_history) > self.config['stateVoteWindow']:
            self.state_history.pop(0)

        counts = {}
        for s in self.state_history:
            counts[s] = counts.get(s, 0) + 1

        winner = self.stable_state
        winner_count = -1
        for candidate, count in counts.items():
            if count > winner_count:
                winner = candidate
                winner_count = count
            elif count == winner_count and candidate == self.stable_state:
                winner = candidate

        return winner

    def _commit_state(self, raw_state):
        if raw_state != self.candidate_state:
            self.candidate_state = raw_state
            self.candidate_frames = 1
        else:
            self.candidate_frames += 1

        if self.candidate_state != self.stable_state and self.candidate_frames >= self.config['stateHoldFrames']:
            self.stable_state = self.candidate_state

        return self.stable_state

    def _detect_gesture(self, landmarks):
        pinch_dist = self._distance3(landmarks[4], landmarks[8])
        hand_scale = max(self._distance3(landmarks[0], landmarks[5]), 1e-6)
        pinch_ratio = pinch_dist / hand_scale

        if self.config['dynamicPinch']:
            pinch_matched = pinch_ratio < self.config['pinchRatioThreshold']
        else:
            pinch_matched = pinch_dist < self.config['pinchThreshold']

        wrist = landmarks[0]
        finger_pairs = [(8, 5), (12, 9), (16, 13), (20, 17)]

        extended_count = 0
        curled_count = 0

        for tip_idx, mcp_idx in finger_pairs:
            tip_dist = self._distance3(landmarks[tip_idx], wrist)
            mcp_dist = self._distance3(landmarks[mcp_idx], wrist)
            delta = tip_dist - mcp_dist

            if delta > self.config['openEnterExtensionThreshold']:
                extended_count += 1
            if delta < self.config['fistEnterCurlThreshold']:
                curled_count += 1

        thumb_dist = self._distance3(landmarks[4], landmarks[2])
        is_open_sticky = (self.stable_state == 'OPEN')
        is_fist_sticky = (self.stable_state == 'FIST')

        # 动态状态粘滞阈值 (Hysteresis)
        open_delta_threshold = self.config['openExitExtensionThreshold'] if is_open_sticky else self.config[
            'openEnterExtensionThreshold']
        fist_delta_threshold = self.config['fistExitCurlThreshold'] if is_fist_sticky else self.config[
            'fistEnterCurlThreshold']
        open_count_threshold = 3 if is_open_sticky else 4
        fist_count_threshold = 3 if is_fist_sticky else 4

        thumb_open_threshold = self.config['thumbExtendedExitThreshold'] if is_open_sticky else self.config[
            'thumbExtendedEnterThreshold']
        thumb_fist_threshold = self.config['thumbCurledExitThreshold'] if is_fist_sticky else self.config[
            'thumbCurledEnterThreshold']

        open_y_gap_threshold = self.config['openExitYGapThreshold'] if is_open_sticky else self.config[
            'openEnterYGapThreshold']
        fist_y_gap_abs_threshold = self.config['fistExitYGapAbsThreshold'] if is_fist_sticky else self.config[
            'fistEnterYGapAbsThreshold']

        open_count = 0
        fist_count = 0
        open_y_count = 0
        fist_y_count = 0

        for tip_idx, mcp_idx in finger_pairs:
            tip_dist = self._distance3(landmarks[tip_idx], wrist)
            mcp_dist = self._distance3(landmarks[mcp_idx], wrist)
            delta = tip_dist - mcp_dist
            y_gap = landmarks[tip_idx]['y'] - landmarks[mcp_idx]['y']
            y_gap_abs = abs(y_gap)

            if delta > open_delta_threshold: open_count += 1
            if delta < fist_delta_threshold: fist_count += 1
            if y_gap < open_y_gap_threshold: open_y_count += 1
            if y_gap_abs < fist_y_gap_abs_threshold: fist_y_count += 1

        thumb_extended_hys = thumb_dist > thumb_open_threshold
        thumb_curled_hys = thumb_dist < thumb_fist_threshold

        pinch_baseline_ready = self.stable_state in ('PINCH', 'OPEN') or (
                    open_y_count >= self.config['pinchOpenBaselineCount'])
        fist_y_count_threshold = 2

        finger_curl_flags = []
        for tip_idx, mcp_idx in finger_pairs:
            tip_dist = self._distance3(landmarks[tip_idx], wrist)
            mcp_dist = self._distance3(landmarks[mcp_idx], wrist)
            delta = tip_dist - mcp_dist
            y_gap_abs = abs(landmarks[tip_idx]['y'] - landmarks[mcp_idx]['y'])
            finger_curl_flags.append(delta < fist_delta_threshold or y_gap_abs < fist_y_gap_abs_threshold)

        index_curled, middle_curled, ring_curled, pinky_curled = finger_curl_flags
        core_fist_ready = index_curled and middle_curled and (ring_curled or pinky_curled)

        pinch_support_pairs = [(12, 9), (16, 13), (20, 17)]
        pinch_support_open_count = 0
        for tip_idx, mcp_idx in pinch_support_pairs:
            tip_dist = self._distance3(landmarks[tip_idx], wrist)
            mcp_dist = self._distance3(landmarks[mcp_idx], wrist)
            delta = tip_dist - mcp_dist
            y_gap = landmarks[tip_idx]['y'] - landmarks[mcp_idx]['y']
            if delta > open_delta_threshold and y_gap < open_y_gap_threshold:
                pinch_support_open_count += 1

        pinch_support_open_threshold = 2 if self.stable_state == 'PINCH' else 3

        # 输出状态树判定
        if pinch_matched and pinch_baseline_ready and pinch_support_open_count >= pinch_support_open_threshold:
            return 'PINCH'

        if open_count >= open_count_threshold and open_y_count >= open_count_threshold and thumb_extended_hys and extended_count >= 3:
            return 'OPEN'

        if core_fist_ready and fist_count >= 2 and fist_y_count >= fist_y_count_threshold and curled_count >= 2 and (
                thumb_curled_hys or self.stable_state == 'FIST'):
            return 'FIST'

        return 'NONE'